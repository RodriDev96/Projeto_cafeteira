# Rtc_rodri Library

A Phillips rodri Real Time Chip Arduino Library

Use the Arduino Library Manager to install me.
